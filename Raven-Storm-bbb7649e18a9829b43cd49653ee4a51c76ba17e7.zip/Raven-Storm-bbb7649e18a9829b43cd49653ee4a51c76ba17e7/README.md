# Raven-Storm Toolkit Beta [![Tweet](https://img.shields.io/twitter/url/http/shields.io.svg?style=social)](https://twitter.com/intent/tweet?text=Raven-Storm%20is%20a%20costumizable%20ddos%20Toolbox&url=https://github.com/Taguar258/Raven-Storm&hashtags=pentesting)
A strong, costomizable ddos + dos + pod script with over 38 functions/commands for testing your own server!(^^)

This project will not be open source, because of security verifications.

Maybe in one of the next versions: Bluetooth POD, Mitm.

<a href="https://m.youtube.com/watch?v=Vjaa3kdpbZs&feature=youtu.be">Quick Video about an older version of Raven-Storm.</a>

<!--![MOSHED-2019-4-30-21-28-15](https://user-images.githubusercontent.com/36562445/56987982-34b0ad00-6b8f-11e9-8c2f-9182a9fcd4f9.gif)--><img align="center" style="center" src="https://user-images.githubusercontent.com/36562445/56987982-34b0ad00-6b8f-11e9-8c2f-9182a9fcd4f9.gif" />
Old picture.

## Documentation:
<a style="color: grey" href="https://taguar258.github.io/Raven-Storm/documentation/">Click here for the documentation.</a>

## What makes it different?
- [x] Automated.
- [x] Effective.
- [x] No root/su/sudo needed.
- [x] Testing supported.
- [x] Supports ddos.
- [X] Over 30 commands, for every use.

- [ ] Please DONT use it ILLEGAL!

## Python version:
Python2

## Test:
A Fritzbox needs a restart after dosing it using 200 threads with 2 mb on port 80.

## Info:
**MIT Taguar258 2019**

**DO NOT USE IT ILLEGAL.**

**DO NOT USE IT ON NOT OWNED SERVERS.**

<!--## Screenshot:

![Screenshot_20190405_181220](https://user-images.githubusercontent.com/36562445/55641522-60c65180-57ce-11e9-8c65-084edc2bfb45.jpg)-->
![Screenshot_20190405_181220](https://user-images.githubusercontent.com/36562445/63696325-bdc4b180-c81a-11e9-89b8-a7ce24df08ca.png)

<!--## Update soon infos:
The next update will include the function of connecting multiple scripts together, so you can use instead of one dos script: multiple dos scripts = ddos.
Alpha update probably in on to two days.
<img width="1440" alt="Bildschirmfoto 2019-08-26 um 16 00 14" src="https://user-images.githubusercontent.com/36562445/63696325-bdc4b180-c81a-11e9-89b8-a7ce24df08ca.png">-->





Thanks to my few "fans".


