# CONTRIBUTING
A perfect issue, needs an shot and correct example.

Just explains the problem, and includes the error:

## Example:
```
Error: Vriable is not defined.

It stops and doesn't work anymore at all.

...
```
